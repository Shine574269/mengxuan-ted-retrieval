Original INT309 Python/Tkinter project. Install pandas numpy scikit-learn matplotlib seaborn, then run python gui_demo.py from this directory.
